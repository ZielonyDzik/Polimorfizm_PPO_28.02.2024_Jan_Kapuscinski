import Animal.*;
import ElectronicMedia.*;

public class Main {
    public static void main(String[] args) {

        Boar greenBoar = new Boar("Zielony Dzik", "Olsztyn", 18, "zielony", 77);
        greenBoar.getInfo();
        greenBoar.animalSound();
        greenBoar.sleep();
        greenBoar.occurance();
        greenBoar.runningSpeed();
        greenBoar.attackPower();

        Cat niceCat = new Cat("Luigi", "Maciej", "Wafel", 4, "Polna 42a/23, Warszawa");
        niceCat.getInfo();
        niceCat.animalSound();
        niceCat.sleep();
        niceCat.occurance();
        niceCat.runningSpeed();
        niceCat.attackPower();

        Dog funnyDog = new Dog("Clifford", "Błażej", "Wafel", 20, "Minimini");
        funnyDog.getInfo();
        funnyDog.animalSound();
        funnyDog.sleep();
        funnyDog.occurance();
        funnyDog.runningSpeed();
        funnyDog.attackPower();

        IAnimal crazyPinguin = new Pingwinio("Pingwinio", "Antarktyda", 14, "Madagaskar", 75);
        crazyPinguin.animalSound();
        crazyPinguin.sleep();
        crazyPinguin.occurance();
        crazyPinguin.runningSpeed();
        crazyPinguin.attackPower();

        IAnimal angryRhino = new Rhino("Romuald", "Afryka", 24, 55, 2300);
        angryRhino.animalSound();
        angryRhino.sleep();
        angryRhino.occurance();
        angryRhino.runningSpeed();
        angryRhino.attackPower();

        Computer firstComputer = new Computer("Acer Pro X2000", "Acer", "Black", 2, true);
        firstComputer.getDescription();
        firstComputer.availability();

        Fridge frozenFridge = new Fridge("Amica FK2525", "Amica", 210, 12, true);
        frozenFridge.getDescription();
        frozenFridge.availability();

        Phone szajsung = new Phone("Redmi Note S11", "Xiaomi", 128, 2, true);
        szajsung.getDescription();
        szajsung.availability();

        Television extraTV = new Television("LG Super 1400", "LG", "TVP 1", 7, false);
        extraTV.getDescription();
        extraTV.availability();

        WashingMachine crazyMachine = new WashingMachine("Whirlpool FF1252", "Whirlpool", 1200, 3, false);
        crazyMachine.getDescription();
        crazyMachine.availability();


    }
}