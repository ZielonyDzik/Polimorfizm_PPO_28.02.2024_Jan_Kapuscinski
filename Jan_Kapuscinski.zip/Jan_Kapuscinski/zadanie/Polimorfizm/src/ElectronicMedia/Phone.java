package ElectronicMedia;

public class Phone extends ElectronicMedia {
    String name;
    String companyName;
    int memory;
    int age;
    boolean isAvailable;

    public Phone(String name, String companyName, int memory, int age, boolean isAvailable) {
        this.name = name;
        this.companyName = companyName;
        this.memory = memory;
        this.age = age;
        this.isAvailable = isAvailable;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getMemory() {
        return memory;
    }

    public void setMemory(int memory) {
        this.memory = memory;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }
    /********************************************************
     * nazwa funkcji: getDescription
     * parametry wejściowe: brak
     * wartość zwracana: Opis urządzenia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void getDescription() {
        System.out.println("Nazwa: " + name + ", nazwa firmy: " + companyName + ", pamięć: " + memory + ", wiek: " + age + ".");
    }
    /********************************************************
     * nazwa funkcji: availability
     * parametry wejściowe: brak
     * wartość zwracana: Informacja czy produkt jest dostępny [true/false]
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void availability() {
        System.out.println("Czy dostępny: " + isAvailable + ".\n");
    }
}
