package ElectronicMedia;

public class Computer extends ElectronicMedia{
    String name;
    String companyName;
    String caseColour;
    int age;
    boolean isAvailable;

    public Computer(String name, String companyName, String caseColour, int age, boolean isAvailable) {
        this.name = name;
        this.companyName = companyName;
        this.caseColour = caseColour;
        this.age = age;
        this.isAvailable = isAvailable;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCaseColour() {
        return caseColour;
    }

    public void setCaseColour(String caseColour) {
        this.caseColour = caseColour;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    /********************************************************
     * nazwa funkcji: getDescription
     * parametry wejściowe: brak
     * wartość zwracana: Opis urządzenia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void getDescription() {
        System.out.println("Nazwa: " + name + ", nazwa firmy: " + companyName + ", kolor obudowy: " + caseColour + ", wiek: " + age + ".");
    }
    /********************************************************
     * nazwa funkcji: availability
     * parametry wejściowe: brak
     * wartość zwracana: Informacja czy produkt jest dostępny [true/false]
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void availability() {
        System.out.println("Czy dostępny: " + isAvailable + ".\n");
    }
}
