package ElectronicMedia;

public abstract class ElectronicMedia {

    /********************************************************
     * nazwa funkcji: getDescription
     * parametry wejściowe: brak
     * wartość zwracana: Opis urządzenia
     * autor: Jan Kapuściński
     * ****************************************************/
    public abstract void getDescription();

    /********************************************************
     * nazwa funkcji: availability
     * parametry wejściowe: brak
     * wartość zwracana: Informacja czy produkt jest dostępny [true/false]
     * autor: Jan Kapuściński
     * ****************************************************/
    public abstract void availability();
}
