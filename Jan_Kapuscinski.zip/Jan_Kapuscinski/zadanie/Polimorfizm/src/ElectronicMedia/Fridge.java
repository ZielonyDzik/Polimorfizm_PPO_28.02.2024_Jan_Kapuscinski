package ElectronicMedia;

public class Fridge extends ElectronicMedia {
    String name;
    String companyName;
    int height;
    int age;
    boolean isAvailable;

    public Fridge(String name, String companyName, int height, int age, boolean isAvailable) {
        this.name = name;
        this.companyName = companyName;
        this.height = height;
        this.age = age;
        this.isAvailable = isAvailable;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    /********************************************************
     * nazwa funkcji: getDescription
     * parametry wejściowe: brak
     * wartość zwracana: Opis urządzenia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void getDescription() {
        System.out.println("Nazwa: " + name + ", nazwa firmy: " + companyName + ", wysokość: " + height + ", wiek: " + age + ".");
    }
    /********************************************************
     * nazwa funkcji: availability
     * parametry wejściowe: brak
     * wartość zwracana: Informacja czy produkt jest dostępny [true/false]
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void availability() {
        System.out.println("Czy dostępny: " + isAvailable + ".\n");
    }
}
