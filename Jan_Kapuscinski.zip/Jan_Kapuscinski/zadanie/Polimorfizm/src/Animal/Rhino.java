package Animal;

public class Rhino implements IAnimal {
    String name;
    String occurencePlace; // miejsce występowania
    int age;
    int hornLenght;
    int weight;

    public Rhino(String name, String occurencePlace, int age, int hornLenght, int weight) {
        this.name = name;
        this.occurencePlace = occurencePlace;
        this.age = age;
        this.hornLenght = hornLenght;
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOccurencePlace() {
        return occurencePlace;
    }

    public void setOccurencePlace(String occurencePlace) {
        this.occurencePlace = occurencePlace;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getHornLenght() {
        return hornLenght;
    }

    public void setHornLenght(int hornLenght) {
        this.hornLenght = hornLenght;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    /********************************************************
     * nazwa funkcji: getInfo
     * parametry wejściowe: brak
     * wartość zwracana: Opis zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    public void getInfo(){
        System.out.println("Zwierzę o nazwie: " + name + ". Występuje w: " + occurencePlace + ". Długość rogu: " + hornLenght + ". Wiek: " + age + ". Waga: " + weight + "kg.");
    }

    /********************************************************
     * nazwa funkcji: animalSound
     * parametry wejściowe: brak
     * wartość zwracana: dźwięk jaki wydaje zwierzę
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void animalSound() {
        System.out.println("Trąbi");
    }

    /********************************************************
     * nazwa funkcji: sleep
     * parametry wejściowe: brak
     * wartość zwracana: informacja o śnie tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void sleep() {
        System.out.println("Dłuugo śpi");
    }

    /********************************************************
     * nazwa funkcji: occurance
     * parametry wejściowe: brak
     * wartość zwracana: informacja o miejscu występowania tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void occurance() {
        System.out.println("Występowanie: Afryka");
    }

    /********************************************************
     * nazwa funkcji: runningSpeed
     * parametry wejściowe: brak
     * wartość zwracana: informacja o prędkości biegu tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void runningSpeed() {
        System.out.println("Prędkość biegu: 55km/h");
    }


    /********************************************************
     * nazwa funkcji: attackPower
     * parametry wejściowe: brak
     * wartość zwracana: informacja o sile ataku tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void attackPower() {
        System.out.println("Siła ataku: Potężna\n");
    }
}

