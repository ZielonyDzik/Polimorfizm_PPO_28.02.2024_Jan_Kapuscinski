package Animal;

public class Boar implements IAnimal {
    String name;
    String occurencePlace; // miejsce występowania
    int age;
    String hairColor;
    int weight;

    public Boar(String name, String occurencePlace, int age, String hairColor, int weight) {
        this.name = name;
        this.occurencePlace = occurencePlace;
        this.age = age;
        this.hairColor = hairColor;
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOccurencePlace() {
        return occurencePlace;
    }

    public void setOccurencePlace(String occurencePlace) {
        this.occurencePlace = occurencePlace;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getHairColor() {
        return hairColor;
    }

    public void setHairColor(String hairColor) {
        this.hairColor = hairColor;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    /********************************************************
     * nazwa funkcji: getInfo
     * parametry wejściowe: brak
     * wartość zwracana: Opis zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    public void getInfo(){
        System.out.println("Zwierzę o nazwie: " + name + ". Występuje w: " + occurencePlace + ". Kolor sierści: " + hairColor + ". Wiek: " + age + ". Waga: " + weight + "kg.");
    }

    /********************************************************
     * nazwa funkcji: animalSound
     * parametry wejściowe: brak
     * wartość zwracana: dźwięk jaki wydaje zwierzę
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void animalSound() {
        System.out.println("Dziku robi wrrr");
    }

    /********************************************************
     * nazwa funkcji: sleep
     * parametry wejściowe: brak
     * wartość zwracana: informacja o śnie tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void sleep() {
        System.out.println("Dziku śpi za krótko");
    }

    /********************************************************
     * nazwa funkcji: occurance
     * parametry wejściowe: brak
     * wartość zwracana: informacja o miejscu występowania tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void occurance() {
        System.out.println("Występowanie: Olsztyn");
    }

    /********************************************************
     * nazwa funkcji: runningSpeed
     * parametry wejściowe: brak
     * wartość zwracana: informacja o prędkości biegu tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void runningSpeed() {
        System.out.println("Prędkość biegu: 50km/h");
    }

    /********************************************************
     * nazwa funkcji: attackPower
     * parametry wejściowe: brak
     * wartość zwracana: informacja o sile ataku tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void attackPower() {
        System.out.println("Siła ataku: Potężna\n");
    }
}
