package Animal;

public class Cat implements IAnimal {
    String name;
    String ownerFirstName;
    String ownerLastName;
    int age;
    String address;

    public Cat(String name, String ownerFirstName, String ownerLastName, int age, String address) {
        this.name = name;
        this.ownerFirstName = ownerFirstName;
        this.ownerLastName = ownerLastName;
        this.age = age;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOwnerFirstName() {
        return ownerFirstName;
    }

    public void setOwnerFirstName(String ownerFirstName) {
        this.ownerFirstName = ownerFirstName;
    }

    public String getOwnerLastName() {
        return ownerLastName;
    }

    public void setOwnerLastName(String ownerLastName) {
        this.ownerLastName = ownerLastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    /********************************************************
     * nazwa funkcji: getInfo
     * parametry wejściowe: brak
     * wartość zwracana: Opis zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    public void getInfo(){
        System.out.println("Zwierzę o nazwie: " + name + ". Imię i nazwisko właściciela: " + ownerFirstName + " " + ownerLastName + ". Wiek: " + age + ". Adres: " + address + ".");
    }

    /********************************************************
     * nazwa funkcji: animalSound
     * parametry wejściowe: brak
     * wartość zwracana: dźwięk jaki wydaje zwierzę
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void animalSound() {
        System.out.println("Miauu");
    }

    /********************************************************
     * nazwa funkcji: sleep
     * parametry wejściowe: brak
     * wartość zwracana: informacja o śnie tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void sleep() {
        System.out.println("Śpi: Za długo");
    }

    /********************************************************
     * nazwa funkcji: occurance
     * parametry wejściowe: brak
     * wartość zwracana: informacja o miejscu występowania tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void occurance() {
        System.out.println("Występowanie: Cały świat");
    }

    /********************************************************
     * nazwa funkcji: runningSpeed
     * parametry wejściowe: brak
     * wartość zwracana: informacja o prędkości biegu tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void runningSpeed() {
        System.out.println("Prędkość biegu: 48km/h");
    }

    /********************************************************
     * nazwa funkcji: attackPower
     * parametry wejściowe: brak
     * wartość zwracana: informacja o sile ataku tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void attackPower() {
        System.out.println("Siła ataku: Mocne zadrapanie\n");
    }
}
