package Animal;

public interface IAnimal{

    /********************************************************
     * nazwa funkcji: animalSound
     * parametry wejściowe: brak
     * wartość zwracana: dźwięk jaki wydaje zwierzę
     * autor: Jan Kapuściński
     * ****************************************************/
    public void animalSound();

    /********************************************************
     * nazwa funkcji: sleep
     * parametry wejściowe: brak
     * wartość zwracana: informacja o śnie tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    public void sleep();
    /********************************************************
     * nazwa funkcji: occurance
     * parametry wejściowe: brak
     * wartość zwracana: informacja o miejscu występowania tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    public void occurance();

    /********************************************************
     * nazwa funkcji: runningSpeed
     * parametry wejściowe: brak
     * wartość zwracana: informacja o prędkości biegu tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    public void runningSpeed();

    /********************************************************
     * nazwa funkcji: attackPower
     * parametry wejściowe: brak
     * wartość zwracana: informacja o sile ataku tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    public void attackPower();
}
