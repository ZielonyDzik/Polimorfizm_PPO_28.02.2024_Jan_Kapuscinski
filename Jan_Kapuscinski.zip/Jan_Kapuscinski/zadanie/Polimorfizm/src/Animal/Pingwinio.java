package Animal;

public class Pingwinio implements IAnimal {
    String name;
    String occurencePlace;
    int age;
    String originPlace;
    int height;

    public Pingwinio(String name, String occurencePlace, int age, String originPlace, int height) {
        this.name = name;
        this.occurencePlace = occurencePlace;
        this.age = age;
        this.originPlace = originPlace;
        this.height = height;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOccurencePlace() {
        return occurencePlace;
    }

    public void setOccurencePlace(String occurencePlace) {
        this.occurencePlace = occurencePlace;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getOriginPlace() {
        return originPlace;
    }

    public void setOriginPlace(String originPlace) {
        this.originPlace = originPlace;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    /********************************************************
     * nazwa funkcji: getInfo
     * parametry wejściowe: brak
     * wartość zwracana: Opis zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    public void getInfo(){
        System.out.println("Zwierzę o nazwie: " + name + ". Występuje w: " + occurencePlace + ". Miejsce pochodzenia: " + originPlace + ". Wiek: " + age + ". Wysokość: " + height + "cm.");
    }

    /********************************************************
     * nazwa funkcji: animalSound
     * parametry wejściowe: brak
     * wartość zwracana: dźwięk jaki wydaje zwierzę
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void animalSound() {
        System.out.println("Ryczy jak osioł");
    }

    /********************************************************
     * nazwa funkcji: sleep
     * parametry wejściowe: brak
     * wartość zwracana: informacja o śnie tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void sleep() {
        System.out.println("Pingwinio śpi optymalnie");
    }

    /********************************************************
     * nazwa funkcji: occurance
     * parametry wejściowe: brak
     * wartość zwracana: informacja o miejscu występowania tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void occurance() {
        System.out.println("Występowanie: Antarktyda");
    }

    /********************************************************
     * nazwa funkcji: runningSpeed
     * parametry wejściowe: brak
     * wartość zwracana: informacja o prędkości biegu tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void runningSpeed() {
        System.out.println("Prędkość biegu: 15km/h");
    }

    /********************************************************
     * nazwa funkcji: attackPower
     * parametry wejściowe: brak
     * wartość zwracana: informacja o sile ataku tego zwierzęcia
     * autor: Jan Kapuściński
     * ****************************************************/
    @Override
    public void attackPower() {
        System.out.println("Siła ataku: Średnia\n");
    }
}
